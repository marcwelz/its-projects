public class Ausweis {

    private boolean isFamily;
    private int mitgliedNummer;

    public Ausweis(boolean isFamily, int mitgliedNummer) {
        this.isFamily = isFamily;
        this.mitgliedNummer = mitgliedNummer;
    }

    public Ausweis() {
    }

    public boolean isFamily() {
        return isFamily;
    }

    public void setFamily(boolean family) {
        isFamily = family;
    }

    public int getMitgliedNummer() {
        return mitgliedNummer;
    }

    public void setMitgliedNummer(int mitgliedNummer) {
        this.mitgliedNummer = mitgliedNummer;
    }
}
